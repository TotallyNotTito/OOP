/*#######################################
ADD DESCRIPTION HERE this part of program
only kick starts the program which running
handles all activities in interface
#######################################*/
#include "header.h"

int main()
{

    interface program;
    //core_data obj;
    //program.run();

    return 0;
}

