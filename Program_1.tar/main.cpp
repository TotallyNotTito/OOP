/*#########################################
This part of the program serves as the user 
interface to have interaction wiht the program
and its setup. Mainly for user to establish
a teacher and the teacher's students while also
providing a test ground for possible scenarios
to be used
##########################################*/

#include "teacher.h"

int main ()
{ 

    //setup for program intro
    cout << "Welcome to this humble LMS Software experience." << '\n';
    cout << "We are creating are classroom environment for the quarter" << '\n';
    cout << "for students and teachers to interact in a consolidated setting" << '\n';
    cout << "by sending messages to the teacher, reviewing lecture content and" << '\n';
    cout << "reviewing homework assignments. The teacher can create content" << '\n';
    cout << "while the student can review all the content related. If there" << '\n';
    cout << "are any questions regarding the content, the student can send" << '\n';
    cout << "the teacher a message. Have a wonderful quarter!" << endl;
    //A whole bunch of new lines
    cout << '\n' << '\n' << '\n' << '\n' << endl;
    

    //having user create teacher 
    cout << "We need to have the teacher first create the course material" << '\n';
    
    cout << "What is the teacher's name?" << endl;

    char info[BUFFER];
    cin.get(info, BUFFER, '\n');
    cin.ignore(BUFFER, '\n');

    //calls character array constructor
    teacher teach(info);

    if(teach.display_teacher());
    else cout << "teacher not in class" << endl;

    cout << '\n' << '\n' <<"Time to enter in the names of your students." << endl;
    //Adding in students
    teach.add_student();

    //displaying students and teacher
    cout << '\n' << '\n' <<"Just checking to make sure everything registered properly." << endl;
    if(teach.display_all()) cout << '\n' << '\n' << "Data saved properly" << endl;
    else cout << "Nothing to display" << endl;

    //searching for a student
    cout << "Going to try searching for a student." << endl;
    if(teach.search_student()) cout << "student found!" << endl;
    else cout << "That student doesn't seem to be in the class." << '\n' << '\n' << endl;

    cout << "Now we need to test remvoing a student" << endl;
    if (teach.remove_student()) cout << "Student removed!" << endl;
    else cout << "Hm nothing changed." << endl;

    if (teach.display_all()) cout << "Is the new class list" << endl;
    
    cout << "Now we are going to test to make sure objects are being saved properly" << endl;
    int choice = 0; 

    do
    {
    if (teach.add_message()) teach.display_message();
    else cout << "Hm, didn't work" << endl;


    cout << "Enter any number to add messages and 0  to stop adding messages" << endl;
    cin >> choice;
    cin.ignore(BUFFER,'\n');

    } while (choice != 0);

    cout << "Let's try removing a message." << endl;
    cout << "What message do you want to remove?" << endl;
    //displaying messages
    teach.display_message();

    //removing message
    //double free error taking place
    if (teach.remove_message()) cout << "Message Removed!" << endl;
    else cout << "Hm, looks like nothing was removed." << endl;
    //displaying new messages
    cout << "New messages being displayed" << endl;
    teach.display_message(); 
    
    

    return 0;

}
